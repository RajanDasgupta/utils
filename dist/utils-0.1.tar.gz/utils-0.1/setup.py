from setuptools import setup
setup(name='utils',
version='0.1',
description='General utility functions',
url='#',
author='rajan',
author_email='rajan.dg@gmail.com',
license='',
packages=['utils'],
install_requires=['easygui', 'numpy', 'os'],
zip_safe=False)