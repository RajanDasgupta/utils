import os
import easygui
import numpy as np

def get_directory():
    """
    Opens prompt to select directory
    """
    return easygui.diropenbox()

def folder_list(directory):
    """
    Returns list of absolute paths of sub-directories
    """
    this_dir = [os.path.join(directory, name) for name in os.listdir(directory)]
    return [name for name in this_dir if os.path.isdir(name)]

def file_list(directory):
    """
    Returns list of absolute paths of files in directory
    """
    this_dir = [os.path.join(directory, name) for name in os.listdir(directory)]
    return [name for name in this_dir if not os.path.isdir(name)]

def random_files(n=5, d=None):
    """
    Returns list of randomly selected files in directory
    """
    if d is None:
        d = get_directory()
    files = file_list(d)
    # Return all files if not enough files in dir
    if n >= len(files):
        return files
    file_inds = [0, 0] 
    # Generate random indices without repetitions
    while len(np.unique(file_inds)) != n:
        file_inds = [round(ind) for ind in np.random.rand(n) * len(files)]
    return [files[ind] for ind in file_inds]

def random_files_recursive(n=5, d=None):
    """
    Returns list of randomly selected files from current directory and subdirectories
    """
    if d is None:
        d = get_directory()
    files = random_files(n, d)
    dirs = folder_list(d)
    # For each subdirectory, call function recursively
    for folder in dirs:
        files += random_files_recursive(n, folder)
    return files